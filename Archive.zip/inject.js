const PLAYERS = {
    "www.youtube.com": {
        next: {
            code: '"KeyN"',
            key: '"n"',
            keyCode: 78,
            shiftKey: true
        },
        prev: {
            code: '"KeyP"',
            key: '"p"',
            keyCode: 80,
            shiftKey: true
        },
        playPause: {
            code: '"KeyK"',
            key: '"k"',
            keyCode: 75
        }
    },
    "music.youtube.com": {
        next: {
            code: '"KeyJ"',
            key: '"j"',
            keyCode: 74
        },
        prev: {
            code: '"KeyK"',
            key: '"k"',
            keyCode: 75
        },
        playPause: {
            code: '"Spacebar"',
            key: '" "',
            keyCode: 32
        }
    }
}

chrome.commands.onCommand.addListener(command => {
    chrome.tabs.query({}, tabs => {
        console.log(tabs)

        const playerTab = tabs
            .sort((a, b) => b.audible - a.audible)
            .map(tab => ({ hostname: new URL(tab.url).hostname, id: tab.id }))
            .find(tab => Object.keys(PLAYERS).includes(tab.hostname))

        if (!playerTab) return

        const player = PLAYERS[playerTab.hostname]
        let action

        switch (command) {
            case "NextTrack":
                action = player.next

                break
            case "PreviousTrack":
                action = player.prev

                break

            case "PlayPause":
                action = player.playPause
                break

            default:
                return
        }

        const injectedCode = `var myScript = document.createElement('script');
            myScript.textContent = 'var e = new KeyboardEvent("keydown", {altKey: false, bubbles : true, cancelBubble: false, cancelable : true, code : ${
                action.code
            },composed: true, defaultPrevented: true, charCode: 0, shiftKey : ${!!action.shiftKey}, key: ${
            action.key
        }, keyCode: ${action.keyCode},location: 0, metaKey: false}); document.dispatchEvent(e);';
            document.head.appendChild(myScript);`

        chrome.tabs.executeScript(playerTab.id, {
            code: injectedCode
        })
    })
})
